package com.example.f_testing_template

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
