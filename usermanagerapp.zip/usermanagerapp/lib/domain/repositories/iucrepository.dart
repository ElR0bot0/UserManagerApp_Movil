abstract class IUCRepository {
  Future<bool> authenticateUC(String email, String password);
}
