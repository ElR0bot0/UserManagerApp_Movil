abstract class IUCRemoteDatasource {
  Future<bool> authenticateUC(String email, String password);
}
