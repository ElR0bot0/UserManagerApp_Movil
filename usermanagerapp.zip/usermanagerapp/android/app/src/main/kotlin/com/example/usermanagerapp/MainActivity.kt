package com.example.usermanagerapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
